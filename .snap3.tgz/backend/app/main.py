"""
Application entrypoint: wires together all routers, middleware, and startup
logic. Run with: uvicorn app.main:app

Keep this file thin - it should only compose things defined elsewhere
(routers, middleware, settings). Business logic never lives here.
"""
from __future__ import annotations

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.gzip import GZipMiddleware

from app.core.auth.routes import router as auth_router
from app.core.audit.routes import router as audit_router
from app.core.dashboards.routes import router as dashboards_router
from app.core.dashboards.kpi_routes import router as kpi_dashboard_router
from app.core.notifications.routes import router as notifications_router
from app.core.permissions.routes import router as permissions_router
from app.core.roles.routes import router as roles_router
from app.core.security.routes import router as security_logs_router
from app.core.settings.config import get_settings
from app.core.users.routes import router as users_router
from app.health.routes import router as health_router
from app.middleware.error_handlers import register_exception_handlers
from app.core.cache import CacheInvalidationMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.security import RequestContextMiddleware, SecurityHeadersMiddleware
from app.modules.finance.accounting.routes import router as finance_accounting_router
from app.modules.finance.revenue.routes import router as finance_revenue_router
from app.modules.finance.attachments.routes import router as finance_attachments_router
from app.modules.finance.budget.routes import router as finance_budget_router
from app.modules.finance.categories.routes import router as finance_categories_router
from app.modules.finance.expenses.routes import router as finance_expenses_router
from app.modules.finance.funding.routes import router as finance_funding_router
from app.modules.finance.reports.routes import router as finance_reports_router
from app.modules.finance.staff.routes import router as finance_staff_router
from app.modules.crm.leads.routes import bookings_router as crm_bookings_router
from app.modules.crm.leads.routes import router as crm_leads_router
from app.modules.crm.teachers.routes import router as crm_teachers_router
from app.modules.crm.dashboard import router as crm_dashboard_router
from app.modules.whatsapp.routes import router as whatsapp_router
from app.modules.marketing.routes import subscriptions_router, campaigns_router
from app.modules.ad_tracking.routes import ads_router as ads_integration_router
from app.modules.ad_tracking.routes import router as snap_integration_router
from app.modules.ad_tracking.routes import leads_router as leads_integration_router
from app.modules.ad_tracking.routes import meta_router as meta_integration_router
from app.modules.ad_tracking.sync import start_background_sync

settings = get_settings()

structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.add_log_level,
        structlog.processors.JSONRenderer(),
    ],
)

app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    docs_url="/api/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if settings.ENVIRONMENT != "production" else None,
)


# ---- CORS: strict allowlist from settings, never a wildcard in production ----
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list(),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)

# ---- Security headers + request logging (order matters: outermost first) ----
app.add_middleware(SecurityHeadersMiddleware)
# cache version bump after successful writes (see app/core/cache.py)
app.add_middleware(CacheInvalidationMiddleware, prefix=settings.API_V1_PREFIX)
# per-kind rate limits (login / auth / upload / heavy / api) - see app/middleware/rate_limit.py
app.add_middleware(RateLimitMiddleware, prefix=settings.API_V1_PREFIX)
# compress JSON responses (the big KPI / report payloads shrink ~5-10x)
app.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=5)
app.add_middleware(RequestContextMiddleware)

# ---- Centralized error handling ----
register_exception_handlers(app)

# ---- Routers ----
app.include_router(health_router)  # no /api prefix - orchestrators expect /health, /ready at root

API_PREFIX = settings.API_V1_PREFIX
app.include_router(auth_router, prefix=API_PREFIX)
app.include_router(users_router, prefix=API_PREFIX)
app.include_router(roles_router, prefix=API_PREFIX)
app.include_router(permissions_router, prefix=API_PREFIX)
app.include_router(dashboards_router, prefix=API_PREFIX)
app.include_router(kpi_dashboard_router, prefix=API_PREFIX)
app.include_router(notifications_router, prefix=API_PREFIX)
app.include_router(audit_router, prefix=API_PREFIX)
app.include_router(security_logs_router, prefix=API_PREFIX)
app.include_router(finance_expenses_router, prefix=API_PREFIX)
app.include_router(finance_categories_router, prefix=API_PREFIX)
app.include_router(finance_attachments_router, prefix=API_PREFIX)
app.include_router(finance_reports_router, prefix=API_PREFIX)
app.include_router(finance_budget_router, prefix=API_PREFIX)
app.include_router(finance_staff_router, prefix=API_PREFIX)
app.include_router(finance_funding_router, prefix=API_PREFIX)
app.include_router(finance_revenue_router, prefix=API_PREFIX)
app.include_router(finance_accounting_router, prefix=API_PREFIX)
app.include_router(crm_leads_router, prefix=API_PREFIX)
app.include_router(crm_bookings_router, prefix=API_PREFIX)
app.include_router(crm_teachers_router, prefix=API_PREFIX)
app.include_router(crm_dashboard_router, prefix=API_PREFIX)
app.include_router(whatsapp_router, prefix=API_PREFIX)
app.include_router(subscriptions_router, prefix=API_PREFIX)
app.include_router(campaigns_router, prefix=API_PREFIX)
app.include_router(snap_integration_router, prefix=API_PREFIX)
app.include_router(ads_integration_router, prefix=API_PREFIX)
app.include_router(meta_integration_router, prefix=API_PREFIX)
app.include_router(leads_integration_router, prefix=API_PREFIX)


@app.on_event("startup")
async def _start_lead_sync() -> None:
    # pulls Meta lead-form leads every few minutes (no-op unless configured)
    start_background_sync()


@app.get("/", include_in_schema=False)
async def root():
    return {"service": settings.APP_NAME, "status": "running"}
