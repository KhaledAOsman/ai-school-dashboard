from __future__ import annotations

import json

import uuid
from collections import defaultdict
from datetime import date, datetime, timezone
from decimal import Decimal

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.audit.service import AuditService
from app.modules.crm.leads.models import Booking, Lead
from app.modules.marketing.models import AdCampaign, AppSetting, Subscription
from app.modules.marketing.schemas import (
    CampaignCreateRequest,
    CampaignListResponse,
    CampaignResponse,
    CampaignUpdateRequest,
    PlatformTotals,
    SubscriptionCreateRequest,
    SubscriptionListResponse,
    SubscriptionResponse,
    SubscriptionTotals,
    SubscriptionUpdateRequest,
)

ZERO = Decimal("0")
PLATFORMS = ("snapchat", "meta", "tiktok")
SETTING_KEYS = (
    "project_start_date", "full_launch_date",  # legacy
    "phase_start", "phase_end",
    "target_subscribers", "target_max_cac", "target_min_conversion", "target_min_attendance",
    "kpi_phases",  # JSON list of phases, each with its own window and targets
)


def _not_found(what: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"{what} غير موجود")


# CRM lead source -> subscription source ("organic" = زيارات مباشرة, which also
# covers the website).
_LEAD_TO_SUB_SOURCE = {"instagram": "meta", "snapchat": "snapchat", "tiktok": "tiktok", "organic": "organic", "website": "organic"}


def lead_source_to_subscription_source(source: str | None) -> str | None:
    return _LEAD_TO_SUB_SOURCE.get(source or "")


class SubscriptionService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.audit = AuditService(db)

    async def list(self, page: int = 1, page_size: int = 25) -> SubscriptionListResponse:
        """One page of subscriptions; `totals` always cover ALL subscriptions."""
        count, paid, disc = (
            await self.db.execute(
                select(
                    func.count(Subscription.id),
                    func.coalesce(func.sum(Subscription.amount_paid), 0),
                    func.coalesce(func.sum(Subscription.discount_amount), 0),
                )
            )
        ).one()
        rows = (
            await self.db.execute(
                select(Subscription)
                .order_by(Subscription.subscribed_at.desc(), Subscription.created_at.desc())
                .limit(page_size)
                .offset((page - 1) * page_size)
            )
        ).scalars().all()
        return SubscriptionListResponse(
            items=[SubscriptionResponse.model_validate(r) for r in rows],
            totals=SubscriptionTotals(
                count=count, total_paid=paid, total_discount=disc, total_list_price=paid + disc
            ),
            total=count,
            page=page,
            page_size=page_size,
            total_pages=max((count + page_size - 1) // page_size, 1),
        )

    async def create(self, payload: SubscriptionCreateRequest, user_id: uuid.UUID) -> Subscription:
        sub = Subscription(**payload.model_dump(), created_by=user_id)
        lead = await self._link_lead(sub)
        self.db.add(sub)
        await self.db.flush()
        await self.audit.record(
            user_id=user_id, action="subscription.create", resource_type="subscription",
            resource_id=str(sub.id), new_value={"full_name": sub.full_name, "amount_paid": str(sub.amount_paid)},
        )
        if lead is not None:
            self._mark_converted(lead, sub, user_id)
        queued = await self._queue_purchase(sub)
        await self.db.commit()
        await self.db.refresh(sub)
        if queued:
            from app.modules.ad_tracking.service import schedule_dispatch
            schedule_dispatch()
        return sub

    async def _link_lead(self, sub: Subscription) -> Lead | None:
        """The CRM customer this subscription belongs to: the given lead_id,
        else the customer with the same phone (so a subscription typed in
        الاشتراكات still closes the right lead). Fills sub.lead_id/source."""
        from app.modules.ad_tracking.service import find_lead_by_phone

        lead = await self.db.get(Lead, sub.lead_id) if sub.lead_id else None
        if lead is None and self.db.get_bind().dialect.name == "postgresql":
            try:
                async with self.db.begin_nested():
                    lead = await find_lead_by_phone(self.db, sub.phone)
            except Exception:  # noqa: BLE001 - linking is best-effort
                lead = None
        if lead is not None:
            sub.lead_id = lead.id
            if not sub.source:
                sub.source = lead_source_to_subscription_source(lead.source)
        return lead

    def _mark_converted(self, lead: Lead, sub: Subscription, user_id: uuid.UUID) -> None:
        from app.modules.crm.leads.models import LeadStage, LeadStageEvent

        lead.is_converted = True
        lead.is_lost = False
        lead.stage = LeadStage.CONVERTED.value
        self.db.add(LeadStageEvent(
            lead_id=lead.id, stage=LeadStage.CONVERTED.value, performed_by=user_id,
            note=f"اشترك — المدفوع {sub.amount_paid} ر.س", created_at=datetime.now(timezone.utc),
        ))

    async def _queue_purchase(self, sub: Subscription) -> bool:
        """Reports the subscription as a purchase (with the amount paid) to the
        ad platform the subscriber came from (Snapchat / Meta / TikTok). Never raises."""
        from app.modules.ad_tracking.models import ConversionStage
        from app.modules.ad_tracking.platforms import ready_platforms
        from app.modules.ad_tracking.service import find_lead_by_phone, purchase_time, queue_conversion
        if not ready_platforms():
            return False
        try:
            lead = await self.db.get(Lead, sub.lead_id) if sub.lead_id else await find_lead_by_phone(self.db, sub.phone)
        except Exception:  # noqa: BLE001
            return False
        return await queue_conversion(
            self.db, lead, ConversionStage.PURCHASE,
            value=sub.amount_paid, ref=sub.id, when=purchase_time(sub.subscribed_at),
        )

    async def update(self, sub_id: uuid.UUID, payload: SubscriptionUpdateRequest, user_id: uuid.UUID) -> Subscription:
        sub = await self.db.get(Subscription, sub_id)
        if sub is None:
            raise _not_found("الاشتراك")
        data = payload.model_dump(exclude_unset=True)
        for k, v in data.items():
            if k in ("full_name", "phone", "amount_paid", "discount_amount", "subscribed_at") and v is None:
                continue
            setattr(sub, k, v)
        await self.audit.record(
            user_id=user_id, action="subscription.update", resource_type="subscription",
            resource_id=str(sub.id), new_value={k: str(v) for k, v in data.items()},
        )
        await self.db.commit()
        await self.db.refresh(sub)
        return sub

    async def delete(self, sub_id: uuid.UUID, user_id: uuid.UUID) -> None:
        sub = await self.db.get(Subscription, sub_id)
        if sub is None:
            raise _not_found("الاشتراك")
        await self.audit.record(
            user_id=user_id, action="subscription.delete", resource_type="subscription",
            resource_id=str(sub.id), previous_value={"full_name": sub.full_name, "amount_paid": str(sub.amount_paid)},
        )
        await self.db.delete(sub)
        await self.db.commit()


class CampaignService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.audit = AuditService(db)

    async def list(self) -> CampaignListResponse:
        rows = (
            await self.db.execute(select(AdCampaign).order_by(AdCampaign.platform, AdCampaign.spend.desc()))
        ).scalars().all()
        platforms = platform_totals(rows)
        return CampaignListResponse(
            items=[CampaignResponse.model_validate(r) for r in rows],
            platforms=platforms,
            total_spend=sum((p.spend for p in platforms), ZERO),
        )

    async def create(self, payload: CampaignCreateRequest, user_id: uuid.UUID) -> AdCampaign:
        c = AdCampaign(**payload.model_dump(), created_by=user_id)
        self.db.add(c)
        await self.db.flush()
        await self.audit.record(
            user_id=user_id, action="campaign.create", resource_type="ad_campaign",
            resource_id=str(c.id), new_value={"platform": c.platform, "name": c.name, "spend": str(c.spend)},
        )
        await self.db.commit()
        await self.db.refresh(c)
        return c

    async def update(self, cid: uuid.UUID, payload: CampaignUpdateRequest, user_id: uuid.UUID) -> AdCampaign:
        c = await self.db.get(AdCampaign, cid)
        if c is None:
            raise _not_found("الحملة")
        data = payload.model_dump(exclude_unset=True)
        for k, v in data.items():
            if k in ("platform", "name", "spend", "counts_as_leads") and v is None:
                continue
            setattr(c, k, v)
        await self.audit.record(
            user_id=user_id, action="campaign.update", resource_type="ad_campaign",
            resource_id=str(c.id), new_value={k: str(v) for k, v in data.items()},
        )
        await self.db.commit()
        await self.db.refresh(c)
        return c

    async def delete(self, cid: uuid.UUID, user_id: uuid.UUID) -> None:
        c = await self.db.get(AdCampaign, cid)
        if c is None:
            raise _not_found("الحملة")
        await self.audit.record(
            user_id=user_id, action="campaign.delete", resource_type="ad_campaign",
            resource_id=str(c.id), previous_value={"platform": c.platform, "name": c.name, "spend": str(c.spend)},
        )
        await self.db.delete(c)
        await self.db.commit()


def platform_totals(campaigns) -> list[PlatformTotals]:
    spend: dict[str, Decimal] = defaultdict(lambda: ZERO)
    leads: dict[str, int] = defaultdict(int)
    count: dict[str, int] = defaultdict(int)
    split: dict[str, list[int]] = defaultdict(lambda: [0, 0, 0])
    for c in campaigns:
        spend[c.platform] += c.spend
        count[c.platform] += 1
        split[c.platform][0] += c.form_leads or 0
        split[c.platform][1] += c.website_leads or 0
        split[c.platform][2] += c.messaging_conversations or 0
        if c.counts_as_leads and c.results_count:
            leads[c.platform] += c.results_count
    out = []
    for p in PLATFORMS:
        s, l = spend[p], leads[p]
        out.append(
            PlatformTotals(
                platform=p, spend=s, leads=l, campaigns=count[p],
                cost_per_lead=(s / l).quantize(Decimal("0.01")) if l else None,
                form_leads=split[p][0], website_leads=split[p][1], messaging_conversations=split[p][2],
            )
        )
    return out


# --------------------------------------------------------------------- KPIs

# The project went live on this date. Registrations made earlier (pre-launch
# website sign-ups that still attended a lecture) are absorbed by the first
# period, otherwise bookings would not match the attendance sheet.

LAUNCH_PERIOD_START = date(2026, 7, 1)

# Year-1 phase defaults (editable by the system administrator).
DEFAULT_PHASE_START = date(2026, 8, 1)
DEFAULT_PHASE_END = date(2027, 8, 1)  # exclusive: one year, Aug 2026 .. Jul 2027

# Management targets for the phase (editable).
TEST_PHASE_TARGETS = {
    "subscribers": 100,        # customers (paid subscribers) to reach
    "max_cac": 1500,           # acquisition cost per customer must stay below (SAR)
    "min_conversion": 15,      # % of those who ATTENDED the lecture that subscribe
    "min_attendance": 60,      # % of recorded sessions that attended
}
_TARGET_KEYS = {
    "target_subscribers": ("subscribers", int),
    "target_max_cac": ("max_cac", float),
    "target_min_conversion": ("min_conversion", float),
    "target_min_attendance": ("min_attendance", float),
}

_AR_MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
_AR_QUARTER = {1: "الأول", 2: "الثاني", 3: "الثالث", 4: "الرابع"}
FAR_FUTURE = date(2100, 1, 1)


def _quarter_bounds(year: int, q: int) -> tuple[date, date]:
    """Inclusive start, EXCLUSIVE end of calendar quarter q (1-4)."""
    start = date(year, 3 * (q - 1) + 1, 1)
    end = date(year + 1, 1, 1) if q == 4 else date(year, 3 * q + 1, 1)
    return start, end


def _quarter_label(year: int, q: int) -> str:
    s, e = _quarter_bounds(year, q)
    last = date.fromordinal(e.toordinal() - 1)
    return f"الربع {_AR_QUARTER[q]} {year} ({_AR_MONTHS[s.month - 1]} – {_AR_MONTHS[last.month - 1]})"


def _add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    return date(d.year + m // 12, m % 12 + 1, 1)


def _op_label(start: date, end: date, n: int) -> str:
    """Operating quarter label, e.g. 'الربع الأول · أغسطس – أكتوبر 2026'."""
    last = date.fromordinal(end.toordinal() - 1)
    span = f"{_AR_MONTHS[start.month - 1]} – {_AR_MONTHS[last.month - 1]} {last.year}"
    if start.year != last.year:
        span = f"{_AR_MONTHS[start.month - 1]} {start.year} – {_AR_MONTHS[last.month - 1]} {last.year}"
    return f"الربع {_AR_QUARTER.get(n, str(n))} · {span}"


def _month_label(d: date) -> str:
    return f"{_AR_MONTHS[d.month - 1]} {d.year}"


def parse_period(period: str | None) -> tuple[int, int]:
    """Legacy half-year parser: '2026-H2' -> (2026, 2)."""
    if not period:
        today = date.today()
        return today.year, 1 if today.month <= 6 else 2
    try:
        year_s, half_s = period.upper().split("-H")
        year, half = int(year_s), int(half_s)
        if half not in (1, 2):
            raise ValueError
        return year, half
    except ValueError:
        raise HTTPException(status_code=422, detail="صيغة الفترة غير صحيحة، المثال: 2026-Q4")


def period_bounds(year: int, half: int) -> tuple[date, date]:
    """Inclusive start, EXCLUSIVE end of a half-year."""
    return (date(year, 1, 1), date(year, 7, 1)) if half == 1 else (date(year, 7, 1), date(year + 1, 1, 1))


def previous_period(year: int, half: int) -> tuple[int, int]:
    return (year, 1) if half == 2 else (year - 1, 2)


def _ratio(a: int | Decimal, b: int | Decimal) -> float | None:
    """Percentage a/b, or None when undefined. A step can never convert more
    than 100% of the previous one; a higher figure only means the two counts
    come from different cohorts (e.g. subscriptions entered for people who
    were never logged as leads), so we report no rate instead of a wrong one."""
    if not b:
        return None
    value = float(a) / float(b) * 100
    return round(value, 1) if value <= 100 else None


def _d(v: str | None) -> date | None:
    try:
        return date.fromisoformat(v) if v else None
    except ValueError:
        return None


class KpiService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------ settings
    async def _raw_settings(self) -> dict[str, str | None]:
        rows = (await self.db.execute(select(AppSetting).where(AppSetting.key.in_(SETTING_KEYS)))).scalars().all()
        found = {r.key: r.value for r in rows}
        return {k: found.get(k) for k in SETTING_KEYS}

    async def get_settings(self) -> dict:
        """Phase window + targets (defaults when never edited)."""
        raw = await self._raw_settings()
        start = _d(raw.get("phase_start")) or DEFAULT_PHASE_START
        end = _d(raw.get("phase_end")) or DEFAULT_PHASE_END  # exclusive
        if end <= start:
            end = DEFAULT_PHASE_END if DEFAULT_PHASE_END > start else date(start.year + 1, start.month, 1)
        targets = dict(TEST_PHASE_TARGETS)
        for key, (name, cast) in _TARGET_KEYS.items():
            v = raw.get(key)
            if v not in (None, ""):
                try:
                    targets[name] = cast(float(v)) if cast is int else cast(v)
                except ValueError:
                    pass
        phases = self._parse_phases(raw.get("kpi_phases"))
        if not phases:  # never edited as phases: the legacy single window is phase 1
            phases = [{"id": "p1", "name": "المرحلة الأولى", "start": start, "end": end, "targets": targets}]
        first = phases[0]
        return {
            # earliest phase window (pre-launch sign-ups are absorbed into it)
            "phase_start": first["start"],
            "phase_end_inclusive": date.fromordinal(first["end"].toordinal() - 1),
            "targets": first["targets"],
            "phases": [self._public_phase(p) for p in phases],
            "_phase_end": first["end"],
            "_phases": phases,
        }

    @staticmethod
    def _public_phase(p: dict) -> dict:
        return {"id": p["id"], "name": p["name"], "start": p["start"],
                "end_inclusive": date.fromordinal(p["end"].toordinal() - 1), "targets": p["targets"]}

    @staticmethod
    def _parse_phases(raw: str | None) -> list[dict]:
        """kpi_phases JSON -> phases sorted by start; end is exclusive internally."""
        if not raw:
            return []
        try:
            items = json.loads(raw)
        except ValueError:
            return []
        out = []
        for i, it in enumerate(items if isinstance(items, list) else []):
            s, e = _d(it.get("start")), _d(it.get("end_inclusive"))
            if not s or not e or e < s:
                continue
            t = dict(TEST_PHASE_TARGETS)
            for name, cast in (("subscribers", int), ("max_cac", float), ("min_conversion", float), ("min_attendance", float)):
                v = (it.get("targets") or {}).get(name)
                if v not in (None, ""):
                    try:
                        t[name] = cast(float(v)) if cast is int else cast(v)
                    except (TypeError, ValueError):
                        pass
            out.append({"id": str(it.get("id") or f"p{i + 1}"), "name": (it.get("name") or f"المرحلة {i + 1}").strip(),
                        "start": s, "end": date.fromordinal(e.toordinal() + 1), "targets": t})
        out.sort(key=lambda p: p["start"])
        return out

    async def save_phases(self, phases: list[dict]) -> dict:
        """Replace the whole list of phases (each with its own targets)."""
        payload = []
        for i, p in enumerate(sorted(phases, key=lambda x: x["start"])):
            payload.append({
                "id": p.get("id") or f"p{i + 1}",
                "name": p["name"].strip(),
                "start": p["start"].isoformat(),
                "end_inclusive": p["end_inclusive"].isoformat(),
                "targets": p["targets"],
            })
        row = await self.db.get(AppSetting, "kpi_phases")
        val = json.dumps(payload, ensure_ascii=False)
        if row is None:
            self.db.add(AppSetting(key="kpi_phases", value=val))
        else:
            row.value = val
        await self.db.commit()
        out = await self.get_settings()
        return {k: v for k, v in out.items() if not k.startswith("_")}

    async def update_settings(self, values: dict) -> dict:
        """values: phase_start / phase_end_inclusive (dates) and
        subscribers / max_cac / min_conversion / min_attendance."""
        mapping: dict[str, str | None] = {}
        if "phase_start" in values:
            v = values["phase_start"]
            mapping["phase_start"] = v.isoformat() if v else None
        if "phase_end_inclusive" in values:
            v = values["phase_end_inclusive"]
            mapping["phase_end"] = date.fromordinal(v.toordinal() + 1).isoformat() if v else None
        for key, (name, _cast) in _TARGET_KEYS.items():
            if name in values:
                mapping[key] = None if values[name] is None else str(values[name])
        for key, val in mapping.items():
            row = await self.db.get(AppSetting, key)
            if row is None:
                self.db.add(AppSetting(key=key, value=val or None))
            else:
                row.value = val or None
        await self.db.commit()
        out = await self.get_settings()
        return {k: v for k, v in out.items() if not k.startswith("_")}

    # ------------------------------------------------------------- periods
    @staticmethod
    def _op_quarters(settings: dict) -> list[dict]:
        """Operating quarters = consecutive 3-month blocks counted from the
        phase start (Aug-Oct, Nov-Jan, Feb-Apr, May-Jul for an August start).
        They shift automatically when the phase start date is edited."""
        start, end = settings["phase_start"], settings["_phase_end"]
        out, n, s = [], 1, start
        while s < end and n <= 12:
            e = _add_months(s, 3) if _add_months(s, 3) <= end else end
            out.append({"n": n, "key": f"Q{n}", "start": s, "end": e, "label": _op_label(s, e, n)})
            n += 1
            s = _add_months(start, 3 * (n - 1))
        return out

    def period_options(self, settings: dict) -> list[dict]:
        """'All periods' first (the default), then one option per phase."""
        opts = [{"key": "all", "label": "كل الفترات", "group": "range"}]
        for p in settings["_phases"]:
            pe = date.fromordinal(p["end"].toordinal() - 1)
            opts.append({"key": f"phase:{p['id']}", "group": "phase",
                         "label": f"{p['name']} ({_AR_MONTHS[p['start'].month - 1]} {p['start'].year} – {_AR_MONTHS[pe.month - 1]} {pe.year})"})
        return opts

    @staticmethod
    def _focus_phase(settings: dict, selected_key: str) -> dict:
        """Phase whose goals are shown: the selected phase, else the one running
        today, else the latest that has started, else the first."""
        phases = settings["_phases"]
        if selected_key.startswith("phase:"):
            pid = selected_key.split(":", 1)[1]
            for p in phases:
                if p["id"] == pid:
                    return p
        today = date.today()
        for p in phases:
            if p["start"] <= today < p["end"]:
                return p
        started = [p for p in phases if p["start"] <= today]
        return started[-1] if started else phases[0]

    def resolve_period(self, period: str | None, settings: dict) -> dict:
        """-> key,label,start,end(exclusive), prev (dict|None)."""
        today = date.today()
        key = (period or "").strip()
        quarters = self._op_quarters(settings)
        if not key:
            key = "all"  # default view: everything since launch
        low = key.lower()
        if low.startswith("phase:"):
            phases = settings["_phases"]
            idx = next((i for i, p in enumerate(phases) if p["id"] == key.split(":", 1)[1]), None)
            if idx is None:
                raise HTTPException(status_code=422, detail="المرحلة غير موجودة")
            p = phases[idx]
            prev = phases[idx - 1] if idx > 0 else None
            return {"key": f"phase:{p['id']}", "label": p["name"], "start": p["start"], "end": p["end"],
                    "prev": {"key": f"phase:{prev['id']}", "label": prev["name"], "start": prev["start"], "end": prev["end"]} if prev else None}
        if low == "all":
            return {"key": "all", "label": "كل الفترات", "start": LAUNCH_PERIOD_START, "end": FAR_FUTURE, "prev": None}
        if low == "phase":
            return {"key": "phase", "label": "المرحلة الأولى", "start": settings["phase_start"], "end": settings["_phase_end"], "prev": None}
        up = key.upper()
        if up.startswith("Q") and up[1:].isdigit():
            n = int(up[1:])
            q = next((x for x in quarters if x["n"] == n), None)
            if q is None:
                raise HTTPException(status_code=422, detail="الربع غير موجود ضمن المرحلة الحالية")
            prev = next((x for x in quarters if x["n"] == n - 1), None)
            return {"key": q["key"], "label": q["label"], "start": q["start"], "end": q["end"],
                    "prev": {"key": prev["key"], "label": prev["label"], "start": prev["start"], "end": prev["end"]} if prev else None}
        if "-Q" in up:  # legacy calendar quarter '2026-Q4'
            try:
                ys, qs = up.split("-Q")
                year, cq = int(ys), int(qs)
                if cq not in (1, 2, 3, 4):
                    raise ValueError
            except ValueError:
                raise HTTPException(status_code=422, detail="صيغة الفترة غير صحيحة، المثال: Q1")
            s, e = _quarter_bounds(year, cq)
            py, pq = (year, cq - 1) if cq > 1 else (year - 1, 4)
            ps, pe = _quarter_bounds(py, pq)
            return {"key": f"{year}-Q{cq}", "label": _quarter_label(year, cq), "start": s, "end": e,
                    "prev": {"key": f"{py}-Q{pq}", "label": _quarter_label(py, pq), "start": ps, "end": pe}}
        year, half = parse_period(key)  # legacy half-year
        s, e = period_bounds(year, half)
        py, ph = previous_period(year, half)
        ps, pe = period_bounds(py, ph)
        return {"key": f"{year}-H{half}", "label": f"{'النصف الأول' if half == 1 else 'النصف الثاني'} {year}", "start": s, "end": e,
                "prev": {"key": f"{py}-H{ph}", "label": f"{'النصف الأول' if ph == 1 else 'النصف الثاني'} {py}", "start": ps, "end": pe}}

    # ------------------------------------------------------------- metrics
    async def _range_metrics(self, start: date, end: date, absorb_until: date, include_undated: bool | None = None, detail: bool = False) -> dict:
        """Funnel / revenue / marketing metrics for [start, end)."""
        start_dt = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
        end_dt = datetime(min(end, FAR_FUTURE).year, min(end, FAR_FUTURE).month, min(end, FAR_FUTURE).day, tzinfo=timezone.utc)

        # CRM funnel: cohort of leads created in the period. A range that
        # starts at launch (up to the phase start) also owns earlier
        # registrations; a range that ends at/before launch has none.
        cohort_start, cohort_end = start_dt, end_dt
        if LAUNCH_PERIOD_START <= start <= max(absorb_until, LAUNCH_PERIOD_START):
            cohort_start = datetime(2000, 1, 1, tzinfo=timezone.utc)
        elif end <= LAUNCH_PERIOD_START:
            cohort_end = cohort_start
        in_period = (Lead.created_at >= cohort_start, Lead.created_at < cohort_end)

        rows = (
            await self.db.execute(
                select(Lead.id, Lead.created_at, Lead.source).where(*in_period)
            )
        ).all()
        # every booking of the cohort's customers (a customer may hold many)
        booking_rows = (
            await self.db.execute(
                select(Booking.lead_id, Booking.attended).join(Lead, Lead.id == Booking.lead_id).where(*in_period)
            )
        ).all()
        bookings_by_lead: dict = defaultdict(list)
        for lead_id, att in booking_rows:
            bookings_by_lead[lead_id].append(att)

        leads = attended = not_attended = pending = 0
        by_source: dict[str, dict[str, int]] = defaultdict(lambda: {"leads": 0, "booked": 0, "attended": 0, "not_attended": 0, "pending": 0})
        by_month: dict[date, dict[str, int]] = defaultdict(lambda: {"leads": 0, "booked": 0, "attended": 0, "subscribers": 0, "revenue": 0})
        for lead_id, created_at, source in rows:
            leads += 1  # customers are unique by phone: one row = one lead
            src = source or "other"
            bucket = by_source[src]
            bucket["leads"] += 1
            # month bucket (registrations before the range start fall in its first month)
            m = date(created_at.year, created_at.month, 1)
            if m < date(start.year, start.month, 1):
                m = date(start.year, start.month, 1)
            by_month[m]["leads"] += 1
            atts = bookings_by_lead.get(lead_id, [])
            for att in atts:
                bucket["booked"] += 1
                by_month[m]["booked"] += 1
                if att is True:
                    attended += 1
                    bucket["attended"] += 1
                    by_month[m]["attended"] += 1
                elif att is False:
                    not_attended += 1
                    bucket["not_attended"] += 1
                else:
                    pending += 1
                    bucket["pending"] += 1
        # Bookings = attended + did not attend + awaiting a status change.
        booked = attended + not_attended + pending
        decided = attended + not_attended  # sessions with a recorded outcome

        # ---- Subscribers & revenue
        sub_rows = (
            await self.db.execute(
                select(Subscription.subscribed_at, Subscription.amount_paid, Subscription.discount_amount).where(
                    Subscription.subscribed_at >= start, Subscription.subscribed_at < end
                )
            )
        ).all()
        subscribers = len(sub_rows)
        revenue = sum((Decimal(r[1] or 0) for r in sub_rows), ZERO)
        discounts = sum((Decimal(r[2] or 0) for r in sub_rows), ZERO)
        for sub_at, paid, _disc in sub_rows:
            m = date(sub_at.year, sub_at.month, 1)
            by_month[m]["subscribers"] += 1
            by_month[m]["revenue"] += int(Decimal(paid or 0))

        # ---- Marketing. Campaigns with explicit dates are matched by
        # overlap; undated (lifetime) campaigns belong to the CURRENT period
        # only - we never guess a historical split.
        today = date.today()
        is_current = (start <= today < end) if include_undated is None else include_undated
        campaigns = (await self.db.execute(select(AdCampaign))).scalars().all()
        used, cumulative = [], False
        for c in campaigns:
            if c.period_start is None and c.period_end is None:
                if is_current:
                    used.append(c)
                    cumulative = True
            else:
                c_start = c.period_start or c.period_end
                c_end = c.period_end or c.period_start
                if c_start < end and c_end >= start:
                    used.append(c)
        platforms = platform_totals(used)
        spend = sum((p.spend for p in platforms), ZERO)

        # Leads per platform come from the CRM (a lead = a person whose name
        # and phone were registered), not from the ad account's results.
        crm_platform = {"instagram": "meta", "snapchat": "snapchat", "tiktok": "tiktok"}
        recorded = {p: 0 for p in PLATFORMS}
        for src, b in by_source.items():
            if src in crm_platform:
                recorded[crm_platform[src]] += b["leads"]
        account = {p.platform: p for p in platforms}
        platforms = [
            p.model_copy(update={
                "leads": recorded[p.platform],
                "cost_per_lead": (p.spend / recorded[p.platform]).quantize(Decimal("0.01")) if recorded[p.platform] else None,
            })
            for p in platforms
        ]
        reported_leads = sum(p.leads for p in platforms)
        recon_rows = []
        for p in platforms:
            acc = account[p.platform]
            rec = p.leads
            recon_rows.append({
                "platform": p.platform,
                "spend": p.spend,
                "reported": acc.leads,
                "form_leads": acc.form_leads,
                "website_leads": acc.website_leads,
                "messaging_conversations": acc.messaging_conversations,
                "recorded": rec,
                "capture_rate": round(rec / acc.leads * 100, 1) if acc.leads else None,
                "gap": acc.leads - rec,
                "real_cpl": p.cost_per_lead,
            })
        reconciliation = {
            "platforms": recon_rows,
            # زيارات مباشرة = organic + the website (one channel for management)
            "other_channels": {"organic": sum(by_source.get(s, {}).get("leads", 0) for s in ("organic", "website"))},
            "total_recorded": leads,
        }

        out = {
            "start": start,
            "end_inclusive": date.fromordinal(min(end, FAR_FUTURE).toordinal() - 1) if end < FAR_FUTURE else today,
            "funnel": {
                "leads": leads,
                "booked": booked,
                "decided": decided,
                "attended": attended,
                "not_attended": not_attended,
                "pending_attendance": pending,
                "subscribers": subscribers,
            },
            "revenue": {
                "subscribers": subscribers,
                "total_paid": revenue,
                "total_discount": discounts,
                "total_list_price": revenue + discounts,
                "avg_paid": (revenue / subscribers).quantize(Decimal("0.01")) if subscribers else None,
            },
            "marketing": {
                "total_spend": spend,
                "reported_leads": reported_leads,
                "cac": (spend / subscribers).quantize(Decimal("0.01")) if subscribers else None,
                "cost_per_lead": (spend / reported_leads).quantize(Decimal("0.01")) if reported_leads else None,
                "roas": round(float(revenue) / float(spend), 2) if spend else None,
                "includes_cumulative": cumulative,
                "platforms": platforms,
                "reconciliation": reconciliation,
            },
        }
        if detail:
            out["sources"] = [{"source": s, **v} for s, v in sorted(by_source.items(), key=lambda kv: -kv[1]["leads"])]
            # monthly series from range start up to the current month
            last_month = date(today.year, today.month, 1)
            first = date(start.year, start.month, 1)
            limit = date(end.year, end.month, 1) if end < FAR_FUTURE else last_month
            months, m = [], first
            while m <= min(limit, max(last_month, first)) and len(months) < 60:
                if m < end:
                    b = by_month.get(m, {"leads": 0, "booked": 0, "attended": 0, "subscribers": 0, "revenue": 0})
                    months.append({"month": m.isoformat(), "label": _month_label(m), **b})
                m = date(m.year + (m.month == 12), m.month % 12 + 1, 1)
            out["series"] = months
        return out

    @staticmethod
    def _funnel_rates(f: dict) -> dict:
        decided = f.get("decided", f["attended"] + f["not_attended"])
        return {
            "lead_to_booked": _ratio(f["booked"], f["leads"]),
            "booked_to_attended": _ratio(f["attended"], decided),      # of sessions with a recorded outcome
            "booked_to_not_attended": _ratio(f["not_attended"], decided),
            "attended_to_subscriber": _ratio(f["subscribers"], f["attended"]),
            "overall": _ratio(f["subscribers"], f["leads"]),
        }

    async def summary(self, period: str | None) -> dict:
        settings = await self.get_settings()
        sel = self.resolve_period(period, settings)
        absorb = settings["phase_start"]
        current = await self._range_metrics(sel["start"], sel["end"], absorb, detail=True)
        current.update({"period": sel["key"], "label": sel["label"]})
        current["funnel_rates"] = self._funnel_rates(current["funnel"])
        previous = None
        if sel["prev"]:
            p = sel["prev"]
            previous = await self._range_metrics(p["start"], p["end"], absorb)
            previous.update({"period": p["key"], "label": p["label"]})
            previous["funnel_rates"] = self._funnel_rates(previous["funnel"])
        goals = await self._phase_goals(settings, self._focus_phase(settings, sel["key"]))
        public = {k: v for k, v in settings.items() if not k.startswith("_")}
        return {
            "current": current,
            "previous": previous,
            "periods": self.period_options(settings),
            "selected": sel["key"],
            "settings": public,
            "phase_goals": goals,
        }

    async def _phase_goals(self, settings: dict, phase: dict) -> dict:
        """Cumulative results over one phase window vs. that phase's targets."""
        start, end = phase["start"], phase["end"]
        today = date.today()
        m = await self._range_metrics(start, end, settings["phase_start"], include_undated=start <= today)
        rates = self._funnel_rates(m["funnel"])
        f = m["funnel"]
        return {
            "id": phase["id"],
            "name": phase["name"],
            "start": start,
            "end_inclusive": date.fromordinal(end.toordinal() - 1),
            "includes_cumulative": m["marketing"]["includes_cumulative"],
            "targets": phase["targets"],
            "metrics": {
                "subscribers": f["subscribers"],
                "cac": m["marketing"]["cac"],
                "total_spend": m["marketing"]["total_spend"],
                "conversion": rates["attended_to_subscriber"],   # subscribers / attended
                "attendance_rate": rates["booked_to_attended"],  # attended / recorded sessions
                "attended": f["attended"],
                "decided": f["decided"],
                "booked": f["booked"],
            },
        }
