"""
BudgetLineService: create/update/submit/approve/reject a budget line, and
compute actual-vs-budget spend.

Approval gate (spec requirement): an expense may only reference a budget
line once that line's status is APPROVED. This is enforced here via
`assert_can_post_expense_against`, called from ExpenseService.create()/
update() whenever a payload includes a budget_line_id.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.audit.service import AuditService
from app.core.permissions.object_policy import ensure_found
from app.modules.finance.budget.models import BudgetLine, BudgetLineApproval
from app.modules.finance.budget.repository import BudgetLineRepository
from app.modules.finance.budget.schemas import (
    BudgetLineCreateRequest,
    BudgetLineRejectRequest,
    BudgetLineUpdateRequest,
)
from app.modules.finance.budget.state_machine import (
    BudgetLineStatus,
    InvalidBudgetTransitionError,
    transition,
)
from app.modules.finance.categories.repository import CategoryRepository


class BudgetLineService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = BudgetLineRepository(db)
        self.category_repo = CategoryRepository(db)
        self.audit = AuditService(db)

    async def _resolve_categories(self, category_ids: list[uuid.UUID]) -> list:
        categories = []
        for cid in category_ids:
            category = await self.category_repo.get_by_id(cid)
            if category is None:
                raise HTTPException(status.HTTP_404_NOT_FOUND, f"Category {cid} not found")
            categories.append(category)
        return categories

    async def _assert_not_budgeted_elsewhere(self, category_ids: list[uuid.UUID], exclude_id: uuid.UUID | None = None) -> None:
        """An account belongs to ONE budget line, so its spend is never counted twice."""
        from sqlalchemy import select
        from app.modules.finance.budget.models import budget_line_categories
        stmt = (
            select(BudgetLine.name)
            .join(budget_line_categories, budget_line_categories.c.budget_line_id == BudgetLine.id)
            .where(
                budget_line_categories.c.category_id.in_(category_ids),
                BudgetLine.is_archived.is_(False),
                BudgetLine.status.notin_(("archived", "rejected")),
            )
        )
        if exclude_id:
            stmt = stmt.where(BudgetLine.id != exclude_id)
        clash = (await self.db.execute(stmt)).first()
        if clash:
            raise HTTPException(status.HTTP_409_CONFLICT, f"أحد الحسابات مربوط بالفعل ببند «{clash[0]}»")

    async def create(self, *, payload: BudgetLineCreateRequest, user_id: uuid.UUID) -> BudgetLine:
        categories = await self._resolve_categories(payload.category_ids)
        await self._assert_not_budgeted_elsewhere(payload.category_ids)

        budget_line = BudgetLine(
            name=payload.name,
            description=payload.description,
            kind=payload.kind,
            period=payload.period,
            budgeted_amount=payload.budgeted_amount,
            currency=payload.currency,
            period_start=payload.period_start,
            period_end=payload.period_end,
            status=BudgetLineStatus.DRAFT.value,
            created_by=user_id,
            categories=categories,
        )
        self.repo.add(budget_line)
        await self.db.flush()

        await self.audit.record(
            user_id=user_id,
            action="budget_line.created",
            resource_type="BudgetLine",
            resource_id=str(budget_line.id),
            new_value={"name": budget_line.name, "budgeted_amount": str(budget_line.budgeted_amount)},
        )
        await self.db.commit()
        return await self.repo.get_by_id(budget_line.id)

    async def update(
        self, *, budget_line_id: uuid.UUID, payload: BudgetLineUpdateRequest, user_id: uuid.UUID
    ) -> BudgetLine:
        """
        Updates a budget line's fields, including its budgeted_amount,
        regardless of current status (draft/pending/approved/rejected).
        This is intentional: a manager may need to correct or adjust an
        already-approved line's amount without going through archive +
        recreate. Every change is captured in the audit log with the exact
        before/after values so the change is fully traceable.
        """
        budget_line = await self.repo.get_by_id(budget_line_id)
        ensure_found(budget_line, "Budget line")

        previous_snapshot = {
            "name": budget_line.name,
            "description": budget_line.description,
            "kind": budget_line.kind,
            "period": budget_line.period,
            "budgeted_amount": str(budget_line.budgeted_amount),
            "period_start": str(budget_line.period_start) if budget_line.period_start else None,
            "period_end": str(budget_line.period_end) if budget_line.period_end else None,
        }

        if payload.name is not None:
            budget_line.name = payload.name
        if payload.description is not None:
            budget_line.description = payload.description
        if payload.kind is not None:
            budget_line.kind = payload.kind
        if payload.period is not None:
            budget_line.period = payload.period
        if payload.budgeted_amount is not None:
            budget_line.budgeted_amount = payload.budgeted_amount
        if payload.period_start is not None:
            budget_line.period_start = payload.period_start
        if payload.period_end is not None:
            budget_line.period_end = payload.period_end
        if payload.category_ids is not None:
            await self._assert_not_budgeted_elsewhere(payload.category_ids, exclude_id=budget_line.id)
            budget_line.categories = await self._resolve_categories(payload.category_ids)

        new_snapshot = {
            "name": budget_line.name,
            "description": budget_line.description,
            "kind": budget_line.kind,
            "period": budget_line.period,
            "budgeted_amount": str(budget_line.budgeted_amount),
            "period_start": str(budget_line.period_start) if budget_line.period_start else None,
            "period_end": str(budget_line.period_end) if budget_line.period_end else None,
        }

        notes = None
        if previous_snapshot["budgeted_amount"] != new_snapshot["budgeted_amount"]:
            notes = (
                f"Budgeted amount changed from {previous_snapshot['budgeted_amount']} "
                f"to {new_snapshot['budgeted_amount']} (status at time of edit: {budget_line.status})"
            )

        await self.audit.record(
            user_id=user_id,
            action="budget_line.updated",
            resource_type="BudgetLine",
            resource_id=str(budget_line.id),
            previous_value=previous_snapshot,
            new_value=new_snapshot,
            notes=notes,
        )
        await self.db.commit()
        return await self.repo.get_by_id(budget_line_id)

    async def get(self, *, budget_line_id: uuid.UUID) -> BudgetLine:
        budget_line = await self.repo.get_by_id(budget_line_id)
        ensure_found(budget_line, "Budget line")
        return budget_line

    async def list_all(self, **filters) -> list[BudgetLine]:
        return await self.repo.list_all(**filters)

    async def spend_summary(self, budget_line: BudgetLine) -> dict:
        """Actual vs budget. A monthly line is compared against its amount times
        the number of months it has been running (start month -> this month),
        and the spend is also returned month by month."""
        spent = await self.repo.spent_amount_for(budget_line.id)
        budgeted = float(budget_line.budgeted_amount)
        budget_to_date = budgeted
        monthly: list[dict] = []
        if budget_line.period == "monthly":
            by_month = await self.repo.spent_by_month(budget_line.id)
            today = date.today()
            first = budget_line.period_start or (
                date(int(min(by_month)[:4]), int(min(by_month)[5:7]), 1) if by_month else today
            )
            last = min(today, budget_line.period_end) if budget_line.period_end else today
            if by_month:
                mx = max(by_month)
                last = max(last, date(int(mx[:4]), int(mx[5:7]), 1))
            y, m = first.year, first.month
            months: list[str] = []
            while (y, m) <= (last.year, last.month):
                months.append(f"{y:04d}-{m:02d}")
                y, m = (y + 1, 1) if m == 12 else (y, m + 1)
            months += [k for k in by_month if k not in months]
            months = sorted(months) or [f"{today.year:04d}-{today.month:02d}"]
            budget_to_date = budgeted * len(months)
            monthly = [{"month": k, "spent": round(by_month.get(k, 0.0), 2), "budget": budgeted} for k in months]
        remaining = budget_to_date - spent
        pct = (spent / budget_to_date * 100) if budget_to_date > 0 else 0.0
        return {
            "spent_amount": round(spent, 2),
            "remaining_amount": round(remaining, 2),
            "spent_pct": round(pct, 1),
            "budget_to_date": round(budget_to_date, 2),
            "months_count": len(monthly) or 1,
            "monthly": monthly,
        }

    async def _apply_transition(
        self,
        *,
        budget_line_id: uuid.UUID,
        to_status: BudgetLineStatus,
        action: str,
        user_id: uuid.UUID,
        reason: str | None = None,
    ) -> BudgetLine:
        budget_line = await self.repo.get_by_id(budget_line_id)
        ensure_found(budget_line, "Budget line")

        from_status = BudgetLineStatus(budget_line.status)
        try:
            transition(from_status, to_status)
        except InvalidBudgetTransitionError as exc:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))

        budget_line.status = to_status.value

        event = BudgetLineApproval(
            budget_line_id=budget_line.id,
            action=action,
            from_status=from_status.value,
            to_status=to_status.value,
            reason=reason,
            performed_by=user_id,
        )
        self.repo.add_approval_event(event)

        await self.audit.record(
            user_id=user_id,
            action=f"budget_line.{action}",
            resource_type="BudgetLine",
            resource_id=str(budget_line.id),
            previous_value={"status": from_status.value},
            new_value={"status": to_status.value},
            notes=reason,
        )
        await self.db.flush()
        return budget_line

    async def submit(self, *, budget_line_id: uuid.UUID, user_id: uuid.UUID) -> BudgetLine:
        await self._apply_transition(
            budget_line_id=budget_line_id, to_status=BudgetLineStatus.PENDING_APPROVAL, action="submit", user_id=user_id
        )
        await self.db.commit()
        return await self.repo.get_by_id(budget_line_id)

    async def approve(self, *, budget_line_id: uuid.UUID, user_id: uuid.UUID) -> BudgetLine:
        budget_line = await self._apply_transition(
            budget_line_id=budget_line_id, to_status=BudgetLineStatus.APPROVED, action="approve", user_id=user_id
        )
        budget_line.approved_by = user_id
        budget_line.approved_at = datetime.now(timezone.utc)
        await self.db.commit()
        return await self.repo.get_by_id(budget_line_id)

    async def reject(
        self, *, budget_line_id: uuid.UUID, payload: BudgetLineRejectRequest, user_id: uuid.UUID
    ) -> BudgetLine:
        budget_line = await self._apply_transition(
            budget_line_id=budget_line_id,
            to_status=BudgetLineStatus.REJECTED,
            action="reject",
            user_id=user_id,
            reason=payload.reason,
        )
        budget_line.rejected_by = user_id
        budget_line.rejected_at = datetime.now(timezone.utc)
        budget_line.rejection_reason = payload.reason
        await self.db.commit()
        return await self.repo.get_by_id(budget_line_id)

    async def archive(self, *, budget_line_id: uuid.UUID, user_id: uuid.UUID) -> BudgetLine:
        await self._apply_transition(
            budget_line_id=budget_line_id, to_status=BudgetLineStatus.ARCHIVED, action="archive", user_id=user_id
        )
        await self.db.commit()
        return await self.repo.get_by_id(budget_line_id)

    async def assert_can_post_expense_against(self, budget_line_id: uuid.UUID) -> None:
        """
        Called from ExpenseService whenever an expense payload references a
        budget_line_id. Enforces the spec requirement: a General Manager
        must approve the LINE before any expense can be posted against it.
        """
        budget_line = await self.repo.get_by_id(budget_line_id)
        ensure_found(budget_line, "Budget line")
        if budget_line.status != BudgetLineStatus.APPROVED.value:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Budget line '{budget_line.name}' is not approved yet (status: {budget_line.status}). "
                "It must be approved by a manager before expenses can be posted against it.",
            )
